const sequelize = require("../config/db")

const {DataTypes} = require("sequelize")


const Subject = sequelize.define("subject",{
    subject_id:{
        type:DataTypes.INTEGER,
        autoIncrement:true,
        primaryKey:true
    },
    title: {
        type:DataTypes.STRING,
        allowNull:false,
    },
    icon: {
        type: DataTypes.TEXT,
        validate: {
            isUrl:true
        }
    }
  

})


module.exports = Subject