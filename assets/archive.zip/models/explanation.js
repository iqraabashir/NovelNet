const sequelize = require("../config/db");

const { DataTypes } = require("sequelize");


const Explanation = sequelize.define("explanations", {
    explantion_id: {
        type:DataTypes.INTEGER,
        autoIncrement:true,
        // defaultValue:DataTypes.UUIDV4,
        primaryKey:true
    },
    explanation:{
        type:DataTypes.TEXT,
        allowNull:false
    },
    message: {
        type:DataTypes.TEXT,
        allowNull:false
    }
})

module.exports = Explanation