const sequelize = require("../config/db")

const {DataTypes} = require("sequelize")


const Teacher  = sequelize.define("teacher" , {
    teacher_id: {
        type: DataTypes.INTEGER,
        autoIncrement:true,

        primaryKey:true
    }
    ,
    // user_id:
    // {
    //     type: DataTypes.UUID,
    //     allowNull: false,
    // },
    full_name : {
        type:DataTypes.STRING(100),
        allowNull: false,   
        validate: {
            isAlpha:true
        }

    },
   specialisation: {
    type:DataTypes.STRING,
    allowNull:false,
    validate: {
        isAlpha:true
    }
   },

    date_of_birth: {
        type: DataTypes.DATE,
        allowNull:false,
        validate:{
            isDate:true
        }
    },


    // course_id: {
    //     type:DataTypes.UUID,
    //     allowNull:false,
    //     validate:
    //     {
    //         isUUID:true
    //     }
    // },

    contact_number: {
        type:DataTypes.BIGINT,
        allowNull:false,
        validate:{
            isNumeric:true,
            len:[10,10]
        }
    },
    other_details: {
        type:DataTypes.STRING,
        allowNull:true,
        
    }

})
module.exports  = Teacher