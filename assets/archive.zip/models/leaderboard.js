// Leaderboard Model
const sequelize = require("../config/db")
const {DataTypes} = require("sequelize")
const Leaderboard = sequelize.define('Leaderboard', {
    leaderboardId: {
      type: DataTypes.UUID,
      primaryKey: true,
      defaultValue: DataTypes.UUIDV4,
    },
    studentId: {
      type: DataTypes.INTEGER, // Assuming studentId is an integer
      allowNull: false,
    },
    marks: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 0, // Initial marks for each student
    },
  });
  
  // Associations
  // Leaderboard.belongsTo(Student, { foreignKey: 'studentId' });
  // Student.hasOne(Leaderboard, { foreignKey: 'studentId' });
  
  module.exports = Leaderboard;
  