const sequelize = require("../config/db");

const { DataTypes } = require("sequelize");

const PushTokens = sequelize.define("Push_Tokens", {
  token_id: {
    type: DataTypes.INTEGER,
    autoIncrement:true,
    primaryKey: true,
  },
  push_token: {
    type: DataTypes.TEXT,
    allowNull: true,
  },

});

module.exports = PushTokens;
