const sequelize = require("../config/db");

const TeachersCourse = sequelize.define(
  "TeachersCourses",
  {},
  { timestamps: false }
);

module.exports = TeachersCourse;
