const sequelize = require("../config/db")

const {DataTypes} = require("sequelize")


const Lecture = sequelize.define("lecture",{
    lecture_id:{
        type:DataTypes.INTEGER,
        autoIncrement:true,
        primaryKey:true
    },
    title: {
        type:DataTypes.STRING,
        allowNull:false,
    },
    video_key:{
        type:DataTypes.STRING,
        allowNull:false,
        
    },
    
    is_paid : {
        type:DataTypes.BOOLEAN,
        allowNull:true,
        defaultValue:false
    },

})


module.exports = Lecture