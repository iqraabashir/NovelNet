const sequelize = require("../config/db");

const { DataTypes } = require("sequelize");

const Question = sequelize.define("question", {
  question_id: {
    type: DataTypes.INTEGER,
    autoIncrement:true,
    primaryKey: true,
  },
  question: {
    type: DataTypes.TEXT,
    allowNull: false,
  },

  option_1: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  option_2: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  option_3: {
    type: DataTypes.STRING,
    allowNull: true,
  },

  option_4: {
    type: DataTypes.STRING,
    allowNull: true,
  },


  answer: {
type:DataTypes.STRING,
allowNull:false
  },
  explanation: {
    type: DataTypes.TEXT,
    allowNull:true
  }
});

module.exports = Question;
