const sequelize = require("../config/db");

const { DataTypes } = require("sequelize");

const MockExams = sequelize.define("mock_exam", {
  exam_id: 
   { type: DataTypes.INTEGER,
     autoIncrement: true,
      primaryKey: true },

  title: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  description: {
    type: DataTypes.TEXT,
    allowNull: false,
  },
});

module.exports = MockExams;
