const sequelize = require("../config/db");

const { DataTypes } = require("sequelize");

const Notification  = sequelize.define("notification", {
    notification_id: {

        type:DataTypes.INTEGER,
        autoIncrement:true,
        primaryKey:true
    },
    title: {
        type:DataTypes.STRING,
        allowNull:false
    },
    body: {
        type: DataTypes.STRING,
        allowNull:false
    }
    
})


module.exports = Notification