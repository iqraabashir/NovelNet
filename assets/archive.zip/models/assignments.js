const { DataTypes } = require("sequelize");
const sequelize = require("../config/db");
const Assignment = sequelize.define("Assignment", {
  assignment_id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    //   defaultValue: DataTypes.UUIDV4,
    autoIncrement: true,
  },
  url: {
    type: DataTypes.STRING,
    allowNull: false,
  },
});

// Associations

module.exports = Assignment;
