const sequelize = require("../config/db")

const {DataTypes} = require("sequelize")



const Course = sequelize.define("course" , {
    course_id: {
        type:DataTypes.INTEGER,
        // defaultValue:1,
        primaryKey:true,
        autoIncrement:true
    },

    course_name: {
        type:DataTypes.STRING,
        allowNull:false,
        unique:{
            name:"unique_course",
            msg: "Course already exists"
        }
    },
    description: {
        type: DataTypes.TEXT,

    },
    // lecture_id:{
    //     type:DataTypes.UUID,
    //     allowNull:false
    // }

  
})


module.exports = Course