const {DataTypes, } = require("sequelize")
const sequelize = require("../config/db")


const Student  = sequelize.define("student" , {
    student_id:{
        type:DataTypes.INTEGER,
        autoIncrement:true,


        primaryKey:true
    },

    // user_id: {
    //     type: DataTypes.UUID,
    //     allowNull:false,
    //     validate:{
    //         isUUID:true
    //     }
        
    // },
    full_name : {
        type:DataTypes.STRING(100),
        allowNull: false,   
     

    },


        
    // },
    date_of_birth: {
        type: DataTypes.DATE,
        allowNull:false,
        validate:{
            isDate:true
        }
    },


    // course_id: {
    //     type:DataTypes.INTEGER,
    //     allowNull:false,
    // },

    contact_number: {
        type:DataTypes.STRING,
        allowNull:false,
        validate:{
            isNumeric:true,
            len:[10,10]
        }
    },
    other_details: {
        type:DataTypes.STRING,
        allowNull:true,
        
    },
    payment_done: {
        type:DataTypes.BOOLEAN,
        allowNull:false,
        defaultValue:false
    }


})

module.exports  = Student