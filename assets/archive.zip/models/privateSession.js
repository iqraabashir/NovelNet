const sequelize = require("../config/db");

const { DataTypes } = require("sequelize");


const PrivateSession = sequelize.define("PrivateSession", {
    session_id:{
        type:DataTypes.INTEGER,
        // defaultValue:DataTypes.UUIDV4
        primaryKey:true,
        autoIncrement:true
    },
    doubt: {
        type: DataTypes.STRING,
        allowNull:true,


    },
    date: {
        type:DataTypes.DATE,
        allowNull:false
    },
    topic: {
        type: DataTypes.TEXT,
        allowNull:false
    }

})





module.exports =  PrivateSession