const { DataTypes } = require("sequelize");
const sequelize = require("../config/db");
require("dotenv").config();
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const Randomstring = require("randomstring");
const User = sequelize.define(
  "user",
  {
    user_id: {
      type: DataTypes.INTEGER,
      autoIncrement:true,
      primaryKey: true,

    },

    email: {
      type: DataTypes.STRING(255),
      allowNull: false,
      unique: {
        name: 'unique_email',
        msg: 'Email address must be unique.'
      },
      validate: {
        isEmail: true,
      },
    },

    password: {
      type: DataTypes.STRING(255),
      allowNull: false,
      set(value) {
        // Use a setter to hash the password before saving it
        const hashedPassword = bcrypt.hashSync(value, 10);
        this.setDataValue("password", hashedPassword);
      },
    
    },



      black_listed: {
        
        type:DataTypes.BOOLEAN,
        defaultValue:false
      },

    user_role: {
      type: DataTypes.ENUM("admin", "student"),
      allowNull: false,
      defaultValue:"student"
    },
    otp: {
      type:DataTypes.TEXT,
      allowNull:true,

      
    },
    expiry :{
      type:DataTypes.DATE,
      allowNull:true
    },
    account_confirmed:{
      type:DataTypes.BOOLEAN,
      defaultValue:false,
    }
    

  },
  {
    hooks: {
      // beforeCreate: async (user, options) => {
      //   await User.hashPassword(user);
      //   return Promise.resolve();
      // },

      beforeUpdate: async (user, options) => {
        await User.hashPassword(user);
        return Promise.resolve();
      },
    },
  }
);

User.hashPassword = async (user) => {
  if (user.changed("password")) {
    user.password = await bcrypt.hash(user.password, 10); // Adjust the salt rounds as needed
  }
};

User.matchPassword = async (password, hashedPassword) => {
  const isMatch = await bcrypt.compare(password, hashedPassword);
  if (isMatch) {
    return true;
  } else {
    return false;
  }
};


User.verifyOtp = async (otp, hashedOtp, expiry) => {
  const date = new Date();
  const expiryTime = new Date(expiry);
  console.log(otp)
  console.log(hashedOtp)
  // console.log(expiry)
  const matched = await bcrypt.compare(otp, hashedOtp);
  console.log(matched)
  console.log(date)
  console.log(expiry)
  if (matched && date < expiryTime) {
    return true;
  } else {
    return false;
  }
};

User.generateOtp = async () => {
  try {
    // console.log("otp is working")
    // generate random otp

    const otp = Randomstring.generate({ length: 6, charset: "numeric" });
    // hash the otp

    const hashedOtp = await bcrypt.hash(otp, 10);
    // generate expiry time

    const expiry = new Date();
    expiry.setMinutes(expiry.getMinutes() + 20);
    return { otp, hashedOtp, expiry };
  } catch (error) {
    return error;
  }
};
User.generateToken = (id) => {
  const token = jwt.sign({ id: id }, process.env.JWT_SECRET_KEY);
  console.log(token)
  console.log(typeof(token))
  return token;
};

module.exports = User;
