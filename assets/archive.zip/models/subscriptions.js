const sequelize = require("../config/db");

const { DataTypes } = require("sequelize");

const Subscriptions = sequelize.define("Subscriptions", {
  subscription_id: {
    type: DataTypes.INTEGER,
    autoIncrement:true,
    primaryKey: true,
  },
  start_date: {
    type: DataTypes.DATE,
    allowNull: false,
  },
  end_date: {
    type:DataTypes.DATE,
    allowNull:false
  }

});

module.exports = Subscriptions;
