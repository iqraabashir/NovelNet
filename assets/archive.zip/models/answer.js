const sequelize = require("../config/db");

const { DataTypes } = require("sequelize");
const Leaderboard = require("./leaderboard");


const Answer = sequelize.define("answer", {
    answer_id:{
        type:DataTypes.INTEGER,
        // defaultValue:DataTypes.UUIDV4
        primaryKey:true,
        autoIncrement:true
    },
    student_answer: {
        type: DataTypes.STRING,
        allowNull:true,


    },
    is_correct: {
        type:DataTypes.BOOLEAN,
        allowNull:false
    }

})





module.exports =  Answer