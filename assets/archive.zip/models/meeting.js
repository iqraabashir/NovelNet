const sequelize = require("../config/db");

const { DataTypes } = require("sequelize");

const Meeting = sequelize.define("meetings",{
    meeting_id: {
        type:DataTypes.INTEGER,
        primaryKey:true,
        autoIncrement:true
    },
    meeting_link: {
        type:DataTypes.TEXT,
        validate: {
            isUrl:true
        },
    },
    meeting_name: {
        type:DataTypes.STRING,
        allowNull:false
    },
    time: {
        type:DataTypes.STRING,
        allowNull:false
    },
    subject_name: {
        type:DataTypes.STRING,
        allowNull:false
    },
    

})

module.exports =Meeting