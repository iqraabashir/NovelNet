const nodemailer = require("nodemailer");
require("dotenv").config()
const transporter = nodemailer.createTransport({
  host: "smtpout.secureserver.net",
  // host: "precepttechnologies.co.in",
  port: 465,
  secure: true,
  auth: {
    user: "info@crescentclasses.in",
    pass: process.env.EMAIL_PASS,
  },
});

module.exports = sendMail = async (data) => {
  // console.log(data.to)
  const mailOptions = {
    from: "info@crescentclasses.in",
    to: "fateennisar121@gmail.com",
    subject: "New Doubt Received",
    html: `
  <p><strong>Full Name:</strong> ${data.full_name}</p>
  <p><strong>Contact Number:</strong> ${data.contact_number}</p>
  <p><strong>Student ID:</strong> ${data.student_id}</p>
  <p><strong>Doubt:</strong> ${data.doubt}</p>
  <p><strong>Topic Name:</strong> ${data.topic}</p>
`,
  };

  try {
    const response = await transporter.sendMail(mailOptions);
    console.log("response");
    return { response: response };
  } catch (err) {
    return { err: err };
  }
};
