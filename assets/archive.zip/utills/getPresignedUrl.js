const AWS = require("aws-sdk");
require("dotenv").config();
AWS.config.update({
  accessKeyId: process.env.WASABI_ACCESS_ID,
  secretAccessKey: process.env.WASABI_SECRET_ID,
  region: "singapore-ap-southeast", // Update with your desired region,
});

const s3 = new AWS.S3({
  endpoint: new AWS.Endpoint("s3.ap-southeast-1.wasabisys.com"),
});
// const upload = multer()

module.exports = (key, expires) => {
  try {
    let preSignedUrl = s3.getSignedUrl("getObject", {
      Bucket: "crescentclassesvideos",
      Key: key,
      Expires: expires,
    });

    return { url: preSignedUrl, success: true };
  } catch (err) {
    return {
      success: false,
    };
  }
};
