const {Expo} = require("expo-server-sdk")
let expo = new Expo({});

module.exports = (somePushTokens, title, body,data) => 
{

    
    let messages = [];
for (let pushToken of somePushTokens) {
    // Each push token looks like ExponentPushToken[xxxxxxxxxxxxxxxxxxxxxx]

    // console.log(pushToken)
    // console.log(somePushTokens  )
    // Check that all your push tokens appear to be valid Expo push tokens
    if (!Expo.isExpoPushToken(pushToken)) {
        console.error(`Push token ${pushToken} is not a valid Expo push token`);
   continue;
}

messages.push({
    to: pushToken,
    sound: 'default',
   title:title,
   body: body,
   data: { withSome: 'data' },
})
}

let chunks = expo.chunkPushNotifications(messages);
let tickets = [];
(async () => {
 for (let chunk of chunks) {
   try {
     let ticketChunk = await expo.sendPushNotificationsAsync(chunk);
     console.log(ticketChunk);
     tickets.push(...ticketChunk);
    } catch (error) {
     console.error(error);
   }
 }
})();


}