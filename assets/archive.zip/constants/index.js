const constants  = {
APP_NAME : "Crescent Classes",
LOGO_URL:"https://f005.backblazeb2.com/file/videosfateentutorapp/logocresent-removebg-preview.png"
}


module.exports = constants