const express = require("express")
const isAuthenticated = require("../middlewares/isAuthenticated")
const isAdmin = require("../middlewares/isAdmin")
const addUserController = require("../controllers/addUserController")
const getAllUsersController = require("../controllers/getAllUsersController")
const viewUserController = require("../controllers/viewUserController")
const deleteUserController = require("../controllers/deleteUserController")
const editProfileController = require("../controllers/editProfileController")
const editUserController = require("../controllers/editUserController")
const router = express.Router()


router.route("/addusers").post(isAuthenticated ,isAdmin , addUserController)
router.route("/getallusers").get(isAuthenticated,isAdmin, getAllUsersController)
router.route("/viewuser/:user_id").get(isAuthenticated,isAdmin, viewUserController)
router.route("/deleteuser").delete(isAuthenticated,isAdmin, deleteUserController)
router.route("/edituserprofile").put(isAuthenticated,isAdmin, editUserController)

module.exports = router