const express = require("express")
const sendNoticationsByCourse = require("../controllers/sendNoticationsByCourse")
const router = express.Router()
const isAuthenticated =  require("../middlewares/isAuthenticated")
const isAdmin =  require("../middlewares/isAdmin")
const getNotificationsController = require("../controllers/getNotificationsController")

router.route("/sendnotification").post(isAuthenticated, isAdmin, sendNoticationsByCourse)
router.route("/getnotifications/:course_id").get(isAuthenticated, getNotificationsController)


module.exports  = router