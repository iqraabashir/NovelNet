const express = require("express")
const isAdmin = require("../middlewares/isAdmin")
const isAuthenticated = require("../middlewares/isAuthenticated")
const { subscribe } = require("./topicRoute")
const subscribeController = require("../controllers/subscribeController")
const checkSubscriptionController = require("../controllers/checkSubscriptionController")
const getAllSubscriptionsController = require("../controllers/getAllSubscriptionsController")
const viewSubscriptionController = require("../controllers/viewSubscriptionController")
const router = express.Router()


router.route("/subscribe").post(isAuthenticated, subscribeController)
router.route("/checksubscription").get(isAuthenticated, checkSubscriptionController)
router.route("/viewsubscription/:subscription_id").get(isAuthenticated,isAdmin, viewSubscriptionController)
router.route("/getallsubscriptions").get(isAuthenticated,isAdmin, getAllSubscriptionsController)

module.exports = router