const express = require("express")
const router = express.Router()
const isAuthenticated = require("../middlewares/isAuthenticated")
const addCourse = require("../controllers/addCourse")
const isAdmin = require("../middlewares/isAdmin")
const deleteCourseController = require("../controllers/deleteCourseController")
const editCourseController = require("../controllers/editCourseController")
const viewCourseController = require("../controllers/viewCourseController")
const getCoursesController = require("../controllers/getCoursesController")
const addAssignmentsController = require("../controllers/addAssignmentsController")
const getAssignmentsController = require("../controllers/getAssignmentsController")
const deleteAssignmentController = require("../controllers/deleteAssignmentController")


/* ----------------------------------- add ---------------------------------- */
router.route("/addassignment").post(isAuthenticated,isAdmin, addAssignmentsController)
/* --------------------------------- delete --------------------------------- */
router.route("/deleteassignment").delete(isAuthenticated,isAdmin, deleteAssignmentController)
// router.route("/deleteassignment").delete(isAuthenticated,isAdmin, deleteCourseController)
/* ----------------------------- /edit/ update ---------------------------- */
// router.route("/editassignment").put(isAuthenticated,isAdmin, editCourseController)
/* ---------------------------------- view ---------------------------------- */
// router.route("/viewco/:course_id").get(isAuthenticated, viewCourseController)

/* --------------------------------- get all -------------------------------- */
router.route("/getassignmentsbylecture/:lecture_id").get(isAuthenticated, getAssignmentsController)

/* ------------------------------- get courses ------------------------------ */

// router.route("/getallcourses").get(isAuthenticated,isAdmin, getCoursesController)


module.exports = router