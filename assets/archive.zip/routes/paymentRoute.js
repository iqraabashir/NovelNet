const express = require("express")
const router = express.Router()
const isAuthenticated =  require("../middlewares/isAuthenticated")
const intentsController = require("../controllers/intentsController")
router.route("/payments").post(isAuthenticated, intentsController)
module.exports= router