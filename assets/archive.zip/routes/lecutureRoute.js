const express = require("express")
const addLectureController = require("../controllers/addLecture.Controller")
const isAuthenticated = require("../middlewares/isAuthenticated")
const isAdmin = require("../middlewares/isAdmin")
const deleteLectureController = require("../controllers/deleteLectureController")
const editLectureController = require("../controllers/editLectureController")
const viewLectureController = require("../controllers/viewLectureController")
const getAllLecturesController = require("../controllers/getAllLecturesController")
const getLecturesByCourseController = require("../controllers/getLecturesByCourseController")
const router = express.Router()

router.route("/addlecture").post(isAuthenticated ,isAdmin, addLectureController)
router.route("/deletelecture").delete(isAuthenticated ,isAdmin, deleteLectureController)
router.route("/editlecture").put(isAuthenticated ,isAdmin, editLectureController)
router.route("/viewlecture/:lecture_id").get(isAuthenticated , viewLectureController)
router.route("/getalllectures/:course_id/:subject_id/:topic_id").get(isAuthenticated , getAllLecturesController)
router.route("/getalllecturesbycourse/:course_id").get(isAuthenticated , getLecturesByCourseController)

module.exports= router