const express = require("express")

const router = express.Router()
const isAuthenticated =  require('../middlewares/isAuthenticated')
const isAdmin =  require('../middlewares/isAdmin')
const addExamController = require("../controllers/addExamController")
const deleteExamController = require("../controllers/deleteExamController")
const editExamController = require("../controllers/editExamController")
const viewExamController = require("../controllers/viewExamController")
const getAllExamController = require("../controllers/getAllExamController")

router.route("/addexam").post(isAuthenticated, isAdmin , addExamController)
router.route("/deleteexam").delete(isAuthenticated, isAdmin , deleteExamController)
router.route("/editexam").put(isAuthenticated, isAdmin , editExamController)
router.route("/viewexam/:exam_id").get(isAuthenticated, isAdmin , viewExamController)
router.route("/getallexams/:course_id").get(isAuthenticated, getAllExamController)

module.exports =  router