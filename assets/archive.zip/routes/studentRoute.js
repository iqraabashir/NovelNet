const express = require("express")
const isAuthenticated = require("../middlewares/isAuthenticated")
const solveQuestionController = require("../controllers/solveQuestionController")

const studentProfileController = require("../controllers/studentProfileController")
const getCoursesController = require("../controllers/getCoursesController")
const getAllTopicsController = require("../controllers/getAllTopicsController")
const getAllLecturesController = require("../controllers/getAllLecturesController")
const getAllExamController = require("../controllers/getAllExamController")
const checkProfileExists = require("../controllers/checkProfileExists")
const editProfileController = require("../controllers/editProfileController")
const isVerified = require("../middlewares/isVerified")
const checkAccountVerified = require("../controllers/checkAccountVerified")

const router = express.Router()

router.route("/solvequestion").post(isAuthenticated, solveQuestionController )

router.route("/completeprofilestudent").post(isAuthenticated,studentProfileController)
router.route("/editprofilestudent").put(isAuthenticated,isVerified ,editProfileController)
router.route("/student/getcourses").get(isAuthenticated,getCoursesController)
router.route("/student/gettopics").get(isAuthenticated,getAllTopicsController)
router.route("/student/getlectures").get(isAuthenticated,getAllLecturesController)
router.route("/student/getexams").get(isAuthenticated,getAllExamController)
router.route("/student/checkprofileexists").get(isAuthenticated ,checkProfileExists)

router.route("/student/checkaccountverified").get(isAuthenticated,checkAccountVerified)


module.exports = router