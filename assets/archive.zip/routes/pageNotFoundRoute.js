const express = require("express")
const pageNotFound = require("../controllers/pageNotFound")
const router = express.Router()


router.route("/*").get(pageNotFound )

module.exports = router