const express = require("express")
const router = express.Router()
const isAuthenticated = require("../middlewares/isAuthenticated")
const addCourse = require("../controllers/addCourse")
const isAdmin = require("../middlewares/isAdmin")
const deleteCourseController = require("../controllers/deleteCourseController")
const editCourseController = require("../controllers/editCourseController")
const viewCourseController = require("../controllers/viewCourseController")
const getCoursesController = require("../controllers/getCoursesController")


/* ----------------------------------- add ---------------------------------- */
router.route("/addcourse").post(isAuthenticated,isAdmin, addCourse)
/* --------------------------------- delete --------------------------------- */
router.route("/deletecourse").delete(isAuthenticated,isAdmin, deleteCourseController)
/* ----------------------------- /edit/ update ---------------------------- */
router.route("/editcourse").put(isAuthenticated,isAdmin, editCourseController)
/* ---------------------------------- view ---------------------------------- */
router.route("/viewcourse/:course_id").get(isAuthenticated, viewCourseController)

/* --------------------------------- get all -------------------------------- */
router.route("/getcourses").get(isAuthenticated, getCoursesController)


/* ------------------------------- get courses ------------------------------ */

// router.route("/getallcourses").get(isAuthenticated,isAdmin, getCoursesController)


module.exports = router