const express = require("express")
const isAdmin = require("../middlewares/isAdmin")
const isAuthenticated = require("../middlewares/isAuthenticated")
const insightsController = require("../controllers/insightsController")
const router = express.Router()

router.route("/insights" ).get(isAuthenticated, isAdmin, insightsController)

module.exports  = router