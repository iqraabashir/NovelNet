const express  = require("express")
const isAuthenticated = require("../middlewares/isAuthenticated")
const isAdmin = require("../middlewares/isAdmin")
const addSubjectController = require("../controllers/addSubjectController")
const getSubjectsController = require("../controllers/getSubjectsController")
const editSubjectController = require("../controllers/editSubjectController")
const viewSubjectController = require("../controllers/viewSubjectController")
const deleteSubjectController = require("../controllers/deleteSubjectController")
const router = express.Router()


router.route("/addsubject").post(isAuthenticated, isAdmin, addSubjectController)
router.route("/editsubject").put(isAuthenticated, isAdmin,isAdmin,  editSubjectController)
router.route("/getsubjects/:course_id").get(isAuthenticated, getSubjectsController)
router.route("/viewsubject/:subject_id").get(isAuthenticated, viewSubjectController)
router.route("/deletesubject").delete(isAuthenticated, isAdmin ,deleteSubjectController)

module.exports = router