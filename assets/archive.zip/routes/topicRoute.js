const express = require("express")
const router = express.Router()
const isAuthenticated = require("../middlewares/isAuthenticated")
const isAdmin = require("../middlewares/isAdmin")
const addTopicController = require("../controllers/addTopicController")
const deleteTopicController = require("../controllers/deleteTopicController")
const editTopicController = require("../controllers/editTopicController")
const viewTopicController = require("../controllers/viewTopicController")
const getAllTopicsController = require("../controllers/getAllTopicsController")



/* ----------------------------------- add  topics---------------------------------- */
router.route("/addtopic").post(isAuthenticated, isAdmin, addTopicController)
/* --------------------------------- delete  topics--------------------------------- */
router.route("/deletetopic").delete(isAuthenticated, isAdmin, deleteTopicController)
/* ----------------------------------- put  topics---------------------------------- */
router.route("/edittopic").put(isAuthenticated, isAdmin, editTopicController)
/* ---------------------------------- view topics ---------------------------------- */ 
router.route("/viewtopic/:topic_id").get(isAuthenticated, isAdmin, viewTopicController)
/* -------------------------------- get all topics ---------------------------- */
router.route("/getalltopics/:subject_id/:course_id").get(isAuthenticated, getAllTopicsController)



module.exports = router