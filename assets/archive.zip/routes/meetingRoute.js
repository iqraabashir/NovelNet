const express = require("express")
const router = express.Router()
const isAdmin = require("../middlewares/isAdmin")
const isAuthenticated = require("../middlewares/isAuthenticated")
const addMeetingController = require("../controllers/addMeetingController")
const getMeetingsController = require("../controllers/getMeetingsController")

router.route("/addmeeting").post(isAuthenticated, isAdmin, addMeetingController)
router.route("/getmeetings/:course_id").get(isAuthenticated, getMeetingsController)

module.exports = router