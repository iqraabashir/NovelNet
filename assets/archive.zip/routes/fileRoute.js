const express = require("express")
const uploadFileController = require("../controllers/uploadFileController")
const router = express.Router()
const isAdmin = require("../middlewares/isAdmin")
const isAuthenticated = require("../middlewares/isAuthenticated")
const multer = require("multer")
// const getPresignedUrlController = require("../controllers/getPresignedUrlController")

const upload = multer({ limits: { fileSize: 500 * 1024 * 1024 /* bytes */ } });

router.route("/uploadfile").post(  upload.single("file"), uploadFileController)
// router.route("/getpresignedurl").get( getPresignedUrlController)

module.exports = router