const express = require("express")
const isAuthenticated = require("../middlewares/isAuthenticated")
const isAdmin = require("../middlewares/isAdmin")
const addQuestionsController = require("../controllers/addQuestionsController")
const editQuestionController = require("../controllers/editQuestionController")
const getAllQuestionsController = require("../controllers/getAllQuestionsController")
const bulkAddQuestionsController = require("../controllers/bulkAddQuestionsController")
const deleteQuestionController = require("../controllers/deleteQuestionController")
const router =  express.Router()


router.route("/addquestion").post(isAuthenticated,isAdmin, addQuestionsController)
router.route("/bulkaddquestions").post(isAuthenticated,isAdmin, bulkAddQuestionsController)
router.route("/editquestion").put(isAuthenticated,isAdmin, editQuestionController)
router.route("/deletequestion").delete(isAuthenticated,isAdmin, deleteQuestionController)
router.route("/getallquestions/:exam_id").get(isAuthenticated, getAllQuestionsController)


module.exports = router