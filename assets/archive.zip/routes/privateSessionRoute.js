const express = require("express")
const router = express.Router()
const isAuthenticated = require("../middlewares/isAuthenticated")
const isAdmin = require("../middlewares/isAdmin")
const requestPrivateSessionController = require("../controllers/requestPrivateSessionController")
const getPrivateSessionController = require("../controllers/getPrivateSessionController")


/* ----------------------------------- add ---------------------------------- */
router.route("/requestprivatesession").post(isAuthenticated, requestPrivateSessionController)
router.route("/getprivatesessions").get(isAuthenticated,isAdmin, getPrivateSessionController)

/* ------------------------------- get courses ------------------------------ */

// router.route("/getallcourses").get(isAuthenticated,isAdmin, getCoursesController)


module.exports = router