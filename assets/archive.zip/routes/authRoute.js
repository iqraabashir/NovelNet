const express = require("express")
const registerController = require("../controllers/registerController")
const loginController = require("../controllers/loginController")
const forgetPasswordController = require("../controllers/forgetPasswordController")
const sendOtpController = require("../controllers/sendOtpController")
const confirmAccountController = require("../controllers/confirmAccountController")
const checkAccountVerified = require("../controllers/checkAccountVerified")
const requestAccountDeletionController = require("../controllers/requestAccountDeletionController")
const router = express.Router()


router.route("/register").post(registerController )
router.route("/login").post(loginController )
router.route("/forgetpassword").post(forgetPasswordController)
router.route("/sendotp").post(sendOtpController)
router.route("/confirmaccount").post(confirmAccountController)
router.route("/requestaccountdeletion").delete(requestAccountDeletionController)

module.exports = router