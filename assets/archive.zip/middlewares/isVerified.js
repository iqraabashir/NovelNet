const jwt = require("jsonwebtoken");
const User = require("../models/user");
require("dotenv").config()
module.exports = async (req, res, next) => {
  try {
    const id = req.user.token.id

const user = await User.findByPk(id)



if (!user)
{
    return res.status(400).json({
        success:false,
        error:"not authorized"
    })    
}

if (!user.dataValues.account_confirmed )
{
return res.status(400).json({
    success:false,
    error:"please verify account"
})
}


next()





  } catch (err) {
    console.log(err);
    return res
      .status(400)
      .json({ error: "internal server errorr", success: false });
  }
};

