const jwt = require("jsonwebtoken");
const User = require("../models/user");
require("dotenv").config();
module.exports = async (req, res, next) => {
  try {
    const token = req.cookies?.token || req.headers?.token || req.body?.token;
    // console.log(typeof(token))
    // console.log(req.cookies)
    console.log("token");
    console.log(token);
    if (!token) {
      return res
        .status(401)
        .json({ message: "please login first", success: false });
    }
    jwt.verify(token, process.env.JWT_SECRET_KEY, async (err, decoded) => {
      if (err) {
        console.log(err);
        return res.status(403).json({
          error: "please login firstt",
          message: "error",
          success: false,
        });
      }

      console.log("decodedpm");
      console.log(decoded);
      const user = await User.findByPk(decoded.id);
      if (!user) {
        return res.status(403).json({
          error: "please login first",
          message: "error",
          success: false,
        });
      }

      req.user = {
        token: decoded,
      };
      next();
    });
  } catch (err) {
    console.log(err);
    return res
      .status(400)
      .json({ error: "internal server errorr", success: false });
  }
};
