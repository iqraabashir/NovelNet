require("dotenv").config()
const express = require("express")
const cookieParser = require('cookie-parser')
const app = express()
const sequelize = require("./config/db")
const associations = require("./associations.js/index")
const pageNotFound = require("./routes/pageNotFoundRoute")
const authRoute = require("./routes/authRoute")
// const profileRoute = require("./routes/profileRoute")
const courseRoute = require("./routes/courseRoute")
const topicRoute = require("./routes/topicRoute")
const lectureRoute = require("./routes/lecutureRoute")
const examRoute = require("./routes/examRoute")
const studentRoute = require("./routes/studentRoute")
const questionRoute = require("./routes/questionRoute")
const subjectRoute = require("./routes/subjectRoute")
const assignmentRoute = require("./routes/assignmentRoute")
const userRoute = require("./routes/userRoutes")
const meetingRoute = require("./routes/meetingRoute")
const insightsRoute = require("./routes/insightsRoute")
const subscriptionRoute = require("./routes/subscriptionsRoute")
const paymentRoute = require("./routes/paymentRoute")
const fileRoute = require("./routes/fileRoute")
const notificationRoute = require("./routes/notificationRoute")
const privateSessionRoute = require("./routes/privateSessionRoute")
const cors = require("cors")


//app.use(express.json())
app.use(cookieParser())
app.use(cors())
app.use(express.json({limit: '500mb'}));
app.use(express.urlencoded({limit: '500mb',extended:true}));


/* -------------------------------- server ------------------------------- */
app.listen(process.env.PORT , () => {
    console.log('server started on port 3000')
})


 /* ------------------------------- root route ------------------------------- */

app.get("/" , (req,res) => {
    res.status(200).json({message:"server running" , success:true})
})



// app.use("/api/v1/",pageNotFound)



app.use("/api/v1/", authRoute)
// app.use("/api/v1/", profileRoute)
app.use("/api/v1/", courseRoute)
app.use("/api/v1",topicRoute )
app.use("/api/v1",lectureRoute )
app.use("/api/v1",examRoute )
app.use("/api/v1",studentRoute )
app.use("/api/v1",questionRoute )
app.use("/api/v1",subjectRoute )
app.use("/api/v1",assignmentRoute )
app.use("/api/v1",userRoute )
app.use("/api/v1",meetingRoute )
app.use("/api/v1",insightsRoute )
app.use("/api/v1",subscriptionRoute )
app.use("/api/v1",paymentRoute )

app.use("/api/v1",fileRoute )
app.use("/api/v1",notificationRoute )
app.use("/api/v1",privateSessionRoute )






/* ----------------------------- page not found ----------------------------- */
app.get("*",  (req,res) => {
    res.status(404).json({
        message:"not found",
        success:false
    })
})

sequelize.sync({}).then(() => {
    
    console.log("table has been created")
}).catch((err)=>{
    console.log("error" + err)
})