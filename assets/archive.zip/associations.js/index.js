const User = require("../models/user");
// const Teacher = require('../models/teacher');
const Course = require("../models/course");
const Student = require("../models/student");
const TeachersCourses = require("../models/teachersCourses");
const Lecture = require("../models/lecture");
const MockExam = require("../models/mockExam");
const Question = require("../models/question");
const Subject = require("../models/subject");
const Notification = require("../models/notification");
const Topic = require("../models/topic");
const Answer = require("../models/answer");
const Assignment = require("../models/assignments");
const Meeting = require("../models/meeting");
const PushTokens = require("../models/pushTokens");
const Subscriptions = require("../models/subscriptions");
const PrivateSession = require("../models/privateSession");
User.hasOne(Student, { foreignKey: "user_id" });
Student.belongsTo(User, { foreignKey: "user_id" });
Student.belongsTo(Course, { foreignKey: "course_id" });
Student.hasMany(Answer, { foreignKey: "student_id" });
Student.hasMany(PrivateSession, { foreignKey: "student_id" });
PrivateSession.belongsTo(Student, { foreignKey: "student_id" });
User.hasMany(PushTokens, { foreignKey: "user_id" });
User.hasOne(Subscriptions, { foreignKey: "user_id" });
Subscriptions.belongsTo(User, { foreignKey: "user_id" });
Answer.belongsTo(Question, { foreignKey: "question_id" });
Answer.belongsTo(MockExam, { foreignKey: "exam_id" });
MockExam.hasMany(Answer, { foreignKey: "exam_id" });
MockExam.belongsTo(Course, { foreignKey: "course_id" });
Course.hasMany(Subject, { foreignKey: "course_id" });
Topic.belongsTo(Course, { foreignKey: "course_id" });
Subject.belongsTo(Course, { foreignKey: "course_id" });
Topic.belongsTo(Subject, { foreignKey: "subject_id" });

Meeting.belongsTo(Course, { foreignKey: "course_id" });
Notification.belongsTo(Course, { foreignKey: "course_id" });

Subject.hasMany(Topic, { foreignKey: "subject_id" });
Topic.belongsTo(Subject, { foreignKey: "subject_id" });

Topic.hasMany(Lecture, { foreignKey: "topic_id" });
Lecture.belongsTo(Topic, { foreignKey: "topic_id" });

Lecture.belongsTo(Course, { foreignKey: "course_id" });
Lecture.belongsTo(Subject, { foreignKey: "subject_id" });
Subject.hasMany(MockExam, { foreignKey: "subject_id" });

MockExam.hasMany(Question, { foreignKey: "exam_id" });
Question.belongsTo(MockExam, { foreignKey: "exam_id" });
Question.hasMany(Answer, { foreignKey: "question_id" });

Assignment.belongsTo(Lecture, { foreignKey: "lecture_id" });
Lecture.hasMany(Assignment, { foreignKey: "lecture_id" });

module.exports = {
  User,
  Course,
  Student,
  Lecture,
  MockExam,
  Notification,
  Topic,
};
