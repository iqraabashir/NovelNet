const Topic   = require("../models/topic")
const Lecture   = require("../models/lecture")
module.exports = async (req, res) => 
{

    try {

        const {lecture_id}  = req.body
        

    

    const lecture= await Lecture.findByPk(lecture_id)

  

    if (!lecture)
    {
        return res.status(400).json({
            error:"lecture does not exist.",
            success:false
        })
    }
    


    await lecture.destroy()
    


    return res.status(201).json({
        message:"lecture delelted successfully",
        data:lecture.dataValues,
        success:true
    })




}

catch (error)  {
    console.log(error)
    if (error.name === "SequelizeValidationError") {
        const validationErrors = error.errors.map((err) => ({
          field: err.path,
          message: err.message,
        }));

  
        return res.status(400).json({
          error: "Validation failed",
          details: validationErrors,
          success: false,
        });
      }


    else if (error.name =="SequelizeUniqueConstraintError")
    {

        const constraintErrors = error.errors.map((err) => ({
            field: err.path,
            message: err.message,
          }));
        return res.status(400).json({
            error: constraintErrors,
            details:"constraint error",
            success: false,
          });
    }
    return res.status(500).json({
        success:false, error:"internal server error"
    })
} 


}