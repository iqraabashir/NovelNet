const Exam   = require("../models/mockExam")
module.exports = async (req, res) => 
{

    try {

        const {exam_id}  = req.params
        

    

    const exam = await Exam.findByPk(exam_id)

  

    if (!exam)
    {
        return res.status(400).json({
            error:"exam does not exist.",
            success:false
        })
    }
    


    


    return res.status(201).json({
        message:"ok",
        data:exam.dataValues,
        success:true
    })




}

catch (error)  {
    console.log(error)
    return res.status(500).json({
        success:false, error:"internal server error"
    })
} 


}