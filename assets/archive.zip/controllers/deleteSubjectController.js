const Subject   = require("../models/subject")
// const Course   = require("../models/course")
module.exports = async (req, res) => 
{

    try {

        const {subject_id}  = req.body
        

    

    const subject = await Subject.findByPk(subject_id)

  

    if (!subject)
    {
        return res.status(400).json({
            error:"subject does not exist.",
            success:false
        })
    }
    


    await subject.destroy()
    


    return res.status(201).json({
        message:"subject deleted successfully",
        data:subject.dataValues,
        success:true
    })




}

catch (error)  {
    console.log(error)
    if (error.name === "SequelizeValidationError") {
        const validationErrors = error.errors.map((err) => ({
          field: err.path,
          message: err.message,
        }));

  
        return res.status(400).json({
          error: "Validation failed",
          details: validationErrors,
          success: false,
        });
      }


    else if (error.name =="SequelizeUniqueConstraintError")
    {

        const constraintErrors = error.errors.map((err) => ({
            field: err.path,
            message: err.message,
          }));
        return res.status(400).json({
            error: constraintErrors,
            details:"constraint error",
            success: false,
          });
    }
    return res.status(500).json({
        success:false, error:"internal server error"
    })
} 


}