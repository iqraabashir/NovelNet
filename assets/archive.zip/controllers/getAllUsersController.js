const User = require("../models/user");
const Student = require("../models/student");
const Course = require("../models/course");
const {Op} = require("sequelize")
module.exports = async (req, res) => {
  try {
    const users = await User.findAll({
      where: {
        user_role: {
          [Op.not] :"admin"
        }
      },
      include: [{
        model: Student,

        attributes: ["student_id","full_name", "date_of_birth", "contact_number"],
        include: {
          model:Course,
          attributes:["course_name"]
  
          
        }
      },
      // {
      // } 
    ], raw:true , order:[["user_id","Desc"]]}, );
    if (!users) {
      return res.status(400).json({
        error: "no users exists. try adding a user first",
        success: false,
      });
    }

    return res.status(200).json({
      message: "ok",
      data: users,
      success: true,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      success: false,
      error: "internal server error",
    });
  }
};
