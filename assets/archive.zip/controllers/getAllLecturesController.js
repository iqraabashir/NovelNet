const Lecture   = require("../models/lecture")
const getPresignedUrl = require("../utills/getPresignedUrl")
module.exports = async (req, res) => 
{

    try {

        const {course_id,subject_id, topic_id, }  = req.params
        

    

    const lectures = await Lecture.findAll({
        where: 
        {
            topic_id,
            course_id,
            subject_id
        }
        , 
        order: [
            ["lecture_id",  "DESC" ]
        ]
    })
    if (!lectures)
    {
        return res.status(400).json({
            error:"no lecture exist. try creating a lecture first",
            success:false
        })
    }
    




    return res.status(201).json({
        message:"ok",
        data:lectures,
        success:true
    })




}

catch (error)  {
    console.log(error)
    return res.status(500).json({
        success:false, error:"internal server error"
    })
} 


}