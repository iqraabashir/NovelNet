const Topic   = require("../models/topic")
const Course   = require("../models/course")
module.exports = async (req, res) => 
{

    try {

        const {topic_id , name , description , course_id}  = req.body
        


    

    const topic = await Topic.findByPk(topic_id)
  

    if (!topic)
    {
        return res.status(400).json({
            message:"topic does not exist",
            success:false
        })
    }
    


    await topic.update({
        name,
        description,
        course_id
    })


    return res.status(201).json({
        message:"topic updated successfully",
        data:topic.dataValues,
        success:true
    })




}

catch (error)  {
    console.log(error)
    if (error.name === "SequelizeValidationError") {
        const validationErrors = error.errors.map((err) => ({
          field: err.path,
          message: err.message,
        }));

  
        return res.status(400).json({
          error: "Validation failed",
          details: validationErrors,
          success: false,
        });
      }


    else if (error.name =="SequelizeUniqueConstraintError")
    {

        const constraintErrors = error.errors.map((err) => ({
            field: err.path,
            message: err.message,
          }));
        return res.status(400).json({
            error: constraintErrors,
            details:"constraint error",
            success: false,
          });
    }
    return res.status(500).json({
        success:false, error:"internal server error"
    })
} 


}