const Topic   = require("../models/topic")
const Course   = require("../models/course")
module.exports = async (req, res) => 
{

    try {

        const {topic_id}  = req.params
        

    

    const topic = await Topic.findByPk(topic_id)

  

    if (!topic)
    {
        return res.status(400).json({
            error:"topic does not exist.",
            success:false
        })
    }
    


    


    return res.status(201).json({
        message:"ok",
        data:topic.dataValues,
        success:true
    })




}

catch (error)  {
    console.log(error)
    return res.status(500).json({
        success:false, error:"internal server error"
    })
} 


}