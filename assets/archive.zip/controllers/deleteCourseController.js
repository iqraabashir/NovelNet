const Course = require("../models/course");

module.exports = async (req, res) => {
  try {
    const { course_id } = req.body;


    const course  = await Course.findByPk(course_id)

    console.log(course)

    if (!course)
    {
        return res
      .status(400)
      .json({ message: "course does not exist", success: false});
    }



   const deletedRows= await course.destroy()

        return res.status(201).json({message:"course deleted", success:true})
    
  } catch (error) {
    console.log(error.name)
    if (error.name === "SequelizeValidationError") {
        const validationErrors = error.errors.map((err) => ({
          field: err.path,
          message: err.message,
        }));

  
        return res.status(400).json({
          error: "Validation failed",
          details: validationErrors,
          success: false,
        });
      }


    else if (error.name =="SequelizeUniqueConstraintError")
    {

        const constraintErrors = error.errors.map((err) => ({
            field: err.path,
            message: err.message,
          }));
        return res.status(400).json({
            error: constraintErrors,
            details:"constraint error",
            success: false,
          });
    }
    return res
      .status(400)
      .json({ error: "internal servor error", success: false });
  }
};
