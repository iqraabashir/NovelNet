const Student = require("../models/student");
module.exports = async (req, res) => {
  try {
    const {
      student_id,
      full_name,
      course_id,
      date_of_birth,
      contact_number,
      other_details,
    } = req.body;

    const profile = await Student.findByPk(student_id);

    if (!profile) {
      return res.status(400).json({
        error: "profile does not exist",
        success: false,
      });
    }

    await profile.update({
      full_name,
      course_id,
      date_of_birth,
      contact_number,
      other_details,
    });

    return res.status(201).json({
      message: "profile updated successfully",
      data: profile.dataValues,
      success: true,
    });
  } catch (error) {
    console.log(error);
    if (error.name === "SequelizeValidationError") {
      const validationErrors = error.errors.map((err) => ({
        field: err.path,
        message: err.message,
      }));

      return res.status(400).json({
        error: "Validation failed",
        details: validationErrors,
        success: false,
      });
    } else if (error.name == "SequelizeUniqueConstraintError") {
      const constraintErrors = error.errors.map((err) => ({
        field: err.path,
        message: err.message,
      }));
      return res.status(400).json({
        error: constraintErrors,
        details: "constraint error",
        success: false,
      });
    }
    return res.status(500).json({
      success: false,
      error: "internal server error",
    });
  }
};
