const Assignment = require("../models/assignments");

module.exports = async (req, res) => {
  try {
    const { lecture_id, url} = req.body;


    // const assignments = await Promise.all(
    //     urls.map( (url) => {
    //         Assignment.create({
    //             url,
    //             lecture_id
    //         })
    //     } )
    // )

    const assignment = await Assignment.create({
      url,
      lecture_id
    })


    return res
      .status(201)
      .json({ message: "assignment added ", success: true, data: assignment.dataValues });
  } catch (error) {
    console.log(error.name)
    if (error.name === "SequelizeValidationError") {
        const validationErrors = error.errors.map((err) => ({
          field: err.path,
          message: err.message,
        }));

  
        return res.status(400).json({
          error: "Validation failed",
          details: validationErrors,
          success: false,
        });
      }


    else if (error.name =="SequelizeUniqueConstraintError")
    {

        const constraintErrors = error.errors.map((err) => ({
            field: err.path,
            message: err.message,
          }));
        return res.status(400).json({
            error: constraintErrors,
            details:"constraint error",
            success: false,
          });
    }
    return res
      .status(400)
      .json({ error: "internal servor error", success: false });
  }
};
