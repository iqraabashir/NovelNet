const User = require("../models/user");
module.exports = async (req, res) => {
  try {
    //1.verify otp
    //2. verify user

    const { email, otp } = req.body;
    // const { password } = req.body;
    // const { password } = req.body;
    // const { role } = req.body;

    // // checking user type

    // if (role == "admin") {
    //   return res
    //     .status(401)
    //     .json({ status: false, error: "admin cannot reset the password" });
    // }

    const exists = await User.findOne({
      where: {
        email: email,
      },
    });

    if (!exists) {
      return res
        .status(400)

        .json({ error: "user does not exist", success: false });
    }

    // getting current user
    const verifiedUser = await User.findOne({
      where: {
        email: email,
        account_confirmed: true,
      },
    });

    // console.log(currentUser);
    if (verifiedUser) {
      return res.status(400).json({
        message: "error",
        error: "user already verified",
        success: false,
      });
    }

    // console.log(verifiedUser)

    // get otp session  id from user db

    const otpMatched = await User.verifyOtp(
      otp,
      exists.dataValues.otp,
      exists.dataValues.expiry
    );
    console.log("otp matched" + otpMatched);
    if (otpMatched) {
      // updating password in database
      const updatedUser = await exists.update({
        account_confirmed: true,
        otp: "",
        // expiry: ""
      });

      updatedUser.dataValues.password = "";
      console.log(updatedUser);
      return res
        .status(201)
        .json({
          data: updatedUser.dataValues,
          success: true,
          message: "Account confirmed successfully",
        });
    } else {
      return res.status(400).json({
        success: false,
        error: "invalid or expired otp",
      });
    }
  } catch (error) {
    console.log(error);
    if (error.name === "SequelizeValidationError") {
      const validationErrors = error.errors.map((err) => ({
        field: err.path,
        message: err.message,
      }));

      return res.status(400).json({
        error: "Validation failed",
        details: validationErrors,
        success: false,
      });
    } else if (error.name == "SequelizeUniqueConstraintError") {
      const constraintErrors = error.errors.map((err) => ({
        field: err.path,
        message: err.message,
      }));
      return res.status(400).json({
        error: constraintErrors,
        details: "constraint error",
        success: false,
      });
    }
    return res
      .status(500)
      .json({ status: false, error: "internal server error" });
  }
};
