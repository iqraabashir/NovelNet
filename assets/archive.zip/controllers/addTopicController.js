const Topic = require("../models/topic");
const Subject = require("../models/subject");
module.exports = async (req, res) => {
  try {
    const { subject_id, name, description, course_id } = req.body;

    const subjectExists = await Subject.findByPk(subject_id);
    if (!subjectExists) {
      return res.status(400).json({
        error: "subject does not exist",
        success: false,
      });
    }

    const topicExists = await Topic.findOne({
      where: {
        name,
        course_id,
        // subject_id
      },
    });

    if (topicExists) {
      return res.status(400).json({
        error: "topic already exists. Please choose another topic  name",
        success: false,
      });
    }

    const topic = await Topic.create({
      name,
      subject_id,
      description,
      course_id,
    });

    return res.status(201).json({
      message: "topic added successfully",
      data: topic.dataValues,
      success:true
    });
  } catch (error) {
    console.log(error);
    if (error.name === "SequelizeValidationError") {
      const validationErrors = error.errors.map((err) => ({
        field: err.path,
        message: err.message,
      }));

      return res.status(400).json({
        error: "Validation failed",
        details: validationErrors,
        success: false,
      });
    } else if (error.name == "SequelizeUniqueConstraintError") {
      const constraintErrors = error.errors.map((err) => ({
        field: err.path,
        message: err.message,
      }));
      return res.status(400).json({
        error: constraintErrors,
        details: "constraint error",
        success: false,
      });
    }
    return res.status(500).json({
      success: false,
      error: "internal server error",
    });
  }
};
