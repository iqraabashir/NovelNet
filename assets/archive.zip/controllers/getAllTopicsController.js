const Topic = require("../models/topic");
const Course = require("../models/course");
module.exports = async (req, res) => {
  try {
    const { course_id, subject_id } = req.params;
    const topics = await Topic.findAll({
      where: {
        subject_id,
        course_id,
      },
      order:[["topic_id","DESC"]]
    });
    if (!topics) {
      return res.status(400).json({
        error: "no topic exist. try creating a topic first",
        success: false,
      });
    }

    return res.status(200).json({
      message: "ok",
      data: topics,
      success: true,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      success: false,
      error: "internal server error",
    });
  }
};
