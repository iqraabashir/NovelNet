const Assignment = require("../models/assignments");
module.exports =async  (req,res) => {
    try {
const {assignment_id} = req.body

const assignment = await Assignment.findByPk(assignment_id)

if (!assignment)
{
    return res.status(400).json({
        success:false,
        data:"assignment does not exist"
    })
}
await assignment.destroy()

return res.status(201).json({
    success:true,
    data: "assignment deleted successfully"
})

    }

    catch (err)
    {
        return res.status(500).json({
            success:false,
            error:"internal server error"
        })
    }
}