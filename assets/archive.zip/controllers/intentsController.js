require("dotenv").config()
const stripe =  require("stripe")(process.env.STRIPE_KEY)
const User =require("../models/user")
const Student =require("../models/student")


module.exports = async (req,res) => {
    try { 
        // const { student_id ,customer_name,contact_number} =req.body

        const user_id =req.user.token.id
        if (!user_id )
        {
            return res.status(400).json({
                success:false,
                error:"user ID is required"
        
            })
        }
        const user = await User.findByPk(user_id,{
            include:{
                model:Student,
                attributes:["full_name","contact_number","other_details"]
            }
            ,raw:true
        })
        console.log(user)
        const customer = await stripe.customers.create(
            {
                name:user["student.full_name"],
                email:user.email,
                phone:user['student.contact_number']

            }
        );
        const ephemeralKey = await stripe.ephemeralKeys.create(
          {customer: customer.id},
          {apiVersion: '2023-10-16'}
        );

        const paymentIntent = await stripe.paymentIntents.create({
            amount:15999 * 100,
            currency:"inr",
            customer:customer.id,
            
            
            
            metadata: {
                user_id,
                student_id:user['student.student_id'],
                contact_number:user['student.contact_number']
            }


    })
    return res.status(201).json({
        success:true,
        data:{

            paymentIntent: paymentIntent.client_secret,
            ephemeralKey: ephemeralKey.secret,
            customer: customer.id,
            intentId:paymentIntent.id,
        }
    })
}
catch (err)
{
    console.log(err)
    return res.status(500).json({
        success:false,
        error:"Internal server error"

    })
}
}