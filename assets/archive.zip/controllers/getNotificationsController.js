const Notification= require("../models/notification") 
module.exports = async (req,res) => {

    try {

        const {course_id} = req.params
        // console.log(course_id)

        const notification = await Notification.findAll({
            where: {
                course_id
            },
            order:[
                ["notification_id", "DESC"]
            ]
        })
        
        return res.status(200).json({
            success:true,
            data:notification
        })
        

    }

    catch (error)
    {
        console.log(error)
        return res.status(500).json({
            success:false,
            error:"Internal servor error"
        })
    }


}