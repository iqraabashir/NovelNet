const Subject = require("../models/subject");

module.exports = async (req, res) => {
  try {

    const {course_id} = req.params
    const subjects  = await Subject.findAll({
        where:{
            course_id
        }
    })


    if (!subjects)
    {
        return res
      .status(400)
      .json({ message: "no subject exist", success: false});
    }




        return res.status(201).json({message :"ok", success:true , data:subjects})
    
  } catch (error) {
    console.log(error)
    return res
      .status(400)
      .json({ error: "internal servor error", success: false });
  }
};

