const Answer = require("../models/answer");
const Student = require("../models/student");

module.exports = async (req, res) => {
  try {
    const { data  } = req.body;
    // console.log(data)
    const {exam_id} = req.body
    console.log(exam_id)
    // return
    const user_id = req.user.token.id;

    const student  = await Student.findOne({
      where: {
        user_id
      }
    })
    const answersExists = await Answer.findOne({
      where: {
        student_id:student.dataValues.student_id,
        exam_id,
      },
    });

    if (answersExists) {
        return res
          .status(400)
          .json({ error: "response already recorded", success: false });
      }

    // console.log("Reached here")
    // console.error(exam_id, student_id, data);
    data.forEach(element => {
        element.student_id =student.dataValues.student_id
        element.exam_id = exam_id
    });

    // console.log(data)


   
    const answers = await Answer.bulkCreate(data);

    return res.status(201).json({
      success: true,
      message: "answer solved successfully",
      data: answers,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      success: false,
      error: "internal server error",
    });
  }
};
