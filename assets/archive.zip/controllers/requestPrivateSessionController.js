const Subscriptions = require("../models/subscriptions");
const Student = require("../models/student");
const PrivateSession = require("../models/privateSession");
const sendMail = require("../utills/sendMail");
const {Op} = require("sequelize")
module.exports = async (req, res) => {
  //
  try {
    const user_id = req.user.token.id;
    const { date, doubt, topic } = req.body;
    const student = await Student.findOne({
      where: {
        user_id,
      },
    });
    // check for subscription
    const nowDate = Date.now();

    const subscription = await Subscriptions.findOne({
      where: {
        user_id: req.user.token.id,
      },
      order:[["subscription_id", "DESC"]]
    });

    if (!subscription)
    {
      return res.status(401).json({
        success: false,
        error: "Subscriptions is needed for private sessions ",
      });

    }
    const todayDate = new Date();
    const endDate = new Date(subscription.dataValues.end_date);

    if (todayDate > endDate) {
      return res.status(401).json({
        success: false,
        error: "Subscriptions is needed for private sessions ",
      });
    }
    // if (!subsription) {
    //   return res.status(400).json({
    //     success: false,
    //     error: "Subscriptions is needed for premium videos",
    //   });
    // }

    // save to db

    const privateSession = await PrivateSession.create({
      student_id: student.dataValues.student_id,
      // student_id:student.dataValues.student_id,
      doubt,
      date,
      topic,
    });
    
    console.log(student.dataValues.student_id)
    const data = {
      
      // send mail
      student_id: student.dataValues.student_id,
      full_name: student.dataValues.full_name,
      contact_number: student.dataValues.contact_number,
      doubt,
      topic,
      date,
    };
    const response = await sendMail(data);

    if (response.err) {
      return res.status(400).json({
        error: "error sending mail to admin",
        success: false,
      });
    }
    return res.status(201).json({
      data: "Requested Private Session",
      success: true,
    });
  } catch (err) {
    console.log(err)
    return res.status(500).json({
      success: false,
      error: "internal server error",
    });
  }
};
