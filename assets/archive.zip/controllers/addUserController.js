const sequelize = require("../config/db");
const User = require("../models/user");
const Student = require("../models/student");

module.exports = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const {
      email,
      password,
      full_name,
      date_of_birth,
      contact_number,
      course_id,
    } = req.body;

    const exists = await User.findOne({
      where: {
        email: email,
      },
    });



    if (exists) {
      return res.status(409).json({
        error: "user already exists!",
        success: false,
      });
    }

    const user = await User.create(
      {
        email,
        password,
      },
      {
        transaction: t,
      }
    );


    const profileExists = await Student.findOne({
      where: {
        student_id:user.dataValues.user_id
      }
    })

    if (profileExists)
    {
      return res.status(400).json({
        success:false,
        error:"profile already exists"
      })
    }
    console.log(user.dataValues.user_id)
    const userProfile = await Student.create(
      {
        full_name,
        date_of_birth,
        contact_number,
        user_id: user.dataValues.user_id,
        course_id,
      },
      {
        transaction: t,
      }
    );

    await t.commit();

    return res
      .status(201)
      .json({
        message: "user added ",
        success: true,
        data: { ...user.dataValues, ...userProfile.dataValues },
      });
  } catch (error) {
    await t.rollback();
    console.log(error);
    if (error.name === "SequelizeValidationError") {
      const validationErrors = error.errors.map((err) => ({
        field: err.path,
        message: err.message,
      }));

      return res.status(400).json({
        error: "Validation failed",
        details: validationErrors,
        success: false,
      });
    } else if (error.name == "SequelizeUniqueConstraintError") {
      const constraintErrors = error.errors.map((err) => ({
        field: err.path,
        message: err.message,
      }));
      return res.status(400).json({
        error: constraintErrors,
        details: "constraint error",
        success: false,
      });
    }
    return res
      .status(400)
      .json({ error: "internal servor error", success: false });
  }
};
