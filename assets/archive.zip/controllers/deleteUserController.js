const User   = require("../models/user")
const Student   = require("../models/student")
const sequelize = require("../config/db");
module.exports = async (req, res) => 
{

    const t = await sequelize.transaction();

    try {

        const {user_id}  = req.body
        

    

    const user = await User.findByPk(user_id)

  

    if (!user)
    {
        return res.status(400).json({
            error:"user does not exist.",
            success:false
        })
    }
    
    const profile = await Student.findOne({
        where: {
            user_id:user.dataValues.user_id
        }
    })

    if (!profile)
    {
        await user.destroy()
        return res.status(201).json({
            message:"user delelted successfully",
            // data:.dataValues,
            success:true
        })

    }


    await user.destroy({
        transaction:t
    })
    
    await profile.destroy({
        transaction:t
    })

    // delete the student profile assoicated with user
   
    
    await  t.commit()

    return res.status(201).json({
        message:"user delelted successfully",
        // data:.dataValues,
        success:true
    })




}

catch (error)  {
    console.log(error)
    await t.rollback()
    if (error.name === "SequelizeValidationError") {
        const validationErrors = error.errors.map((err) => ({
          field: err.path,
          message: err.message,
        }));

  
        return res.status(400).json({
          error: "Validation failed",
          details: validationErrors,
          success: false,
        });
      }


    else if (error.name =="SequelizeUniqueConstraintError")
    {

        const constraintErrors = error.errors.map((err) => ({
            field: err.path,
            message: err.message,
          }));
        return res.status(400).json({
            error: constraintErrors,
            details:"constraint error",
            success: false,
          });
    }
    return res.status(500).json({
        success:false, error:"internal server error"
    })
} 


}