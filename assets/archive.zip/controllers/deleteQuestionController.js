const Question = require("../models/question");
module.exports =async  (req,res) => {
    try {
const {question_id} = req.body

const question = await Question.findByPk(question_id)

if (!question)
{
    return res.status(400).json({
        success:false,
        data:"assignment does not exist"
    })
}
await question.destroy()

return res.status(201).json({
    success:true,
    data: "question deleted successfully"
})

    }

    catch (err)
    {
        return res.status(500).json({
            success:false,
            error:"internal server error"
        })
    }
}