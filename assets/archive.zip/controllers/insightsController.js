const Student = require("../models/student")
const Courses = require("../models/course")
const Subjects = require("../models/subject")
const Lectures= require("../models/lecture")
const Questions = require("../models/question")
const Subscriptions = require("../models/subscriptions")
module.exports  = async (req,res) => {

    try {


        const studentCount = await Student.count()
        const coursesCount = await Courses.count()
        const subjectsCount = await Subjects.count()
        const lecturesCount = await Lectures.count()
        const questionsCount = await Questions.count()
        const subscriptionsCount = await Subscriptions.count()

        return res.status(200).json({
            success:true,
            data: {
                studentCount,
                coursesCount,
                subjectsCount,
                lecturesCount,
                questionsCount,
                subscriptionsCount,
                
            }
        })

    }

    catch (error)
    {
        console.log(error)
        return res.status(500).json({
            success:false,
            error:"something went wrong"
        })
    }


}