const Course = require("../models/course");
const Student = require("../models/student");
const User = require("../models/user");

module.exports = async (req, res) => {
  try {
    const user_id = req.user.token.id;
    const student = await Student.findOne({
      where: {
        user_id: user_id,
      },
      include: [
        {
          model: Course,
          attributes: ["course_name"],
        },
        {
            model:User,
            attributes:["email"]
        }
      ],
    });

    if (!student) {
      return res.status(400).json({
        success: false,
        error: "profile does not exist",
      });
    }

    return res.status(200).json({
      data: student,
      success: true,
      message: "ok",
    });
  } catch (error) {
    return res.status(500).json({
      error: "internal server error",
      success: false,
    });
  }
};
