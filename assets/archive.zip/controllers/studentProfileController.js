const User = require("../models/user");
const Student = require("../models/student")
module.exports = async (req, res) => {
  try {
    const {
      full_name,
      date_of_birth,
      contact_number,
      course_id,
      other_details,
    } = req.body;



    const user = await  User.findByPk(req.user.token.id)

    if (user.dataValues.account_verified == false)
    {
      return res.status(400).json({
        success:false,
        error:"account not verified"
      })
    }


    // console.log(req.user.token.id)
    const token = req.user.token.id
    console.log("token",req.user.token)
    // console.log("id")
    console.log("id" + token)
    const profileExists = await Student.findOne({
      where: {
        student_id: token
      }
    })
    if (profileExists)
    {
      return res.status(400).json({
        success:false,
        error:"profile already exists"
      })
    }
   


    const profile= await Student.create({
      full_name,
      date_of_birth,
      contact_number,
      course_id,
      other_details,
      user_id:token
    })


    return res.status(201).json({
      success:true,
      message:"profile created successfully",
      data:profile.dataValues,
      success:true
    })

    






    
  } catch (error) {

    console.log(error)
    if (error.name === "SequelizeValidationError") {
      const validationErrors = error.errors.map((err) => ({
        field: err.path,
        message: err.message,
      }));

      return res.status(400).json({
        error: "Validation failed",
        details: validationErrors,
        success: false,
      });
    }
    return res
      .status(500)
      .json({ success: false, error: "internal server error1" });
  }
};
