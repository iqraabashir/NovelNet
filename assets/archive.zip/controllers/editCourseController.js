const Course = require("../models/course");

module.exports = async (req, res) => {
  try {
    const { course_id, course_name, description } = req.body;

    const course = await Course.findByPk(course_id);

    if (!course)
    {
        return res.status(400).json({error:"course doest not exist", success:false})
    }

    const updateCourse = await course.update({
        course_name,
        description,
    })

    return res
      .status(201)
      .json({ message: "course updated", success: true, data: course });
  } catch (error) {
    console.log(error.name)
    if (error.name === "SequelizeValidationError") {
        const validationErrors = error.errors.map((err) => ({
          field: err.path,
          message: err.message,
        }));

  
        return res.status(400).json({
          error: "Validation failed",
          details: validationErrors,
          success: false,
        });
      }


    else if (error.name =="SequelizeUniqueConstraintError")
    {

        const constraintErrors = error.errors.map((err) => ({
            field: err.path,
            message: err.message,
          }));
        return res.status(400).json({
            error: constraintErrors,
            details:"constraint error",
            success: false,
          });
    }
    return res
      .status(400)
      .json({ error: "internal servor error", success: false });
  }
};
