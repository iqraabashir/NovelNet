// const decrpytData = require("../utils/decryptData");
// const verifyOtp = require("../utils/verifyOtp");
// const sendOtp = require("../utils/sendOtp");
// const encryptData = require("../utils/encryptData");

const User = require("../models/user");
module.exports = async (req, res) => {
  try {
    // get type of user

    // getting body
    const { email } = req.body;
    const { password } = req.body;
    // const { password } = req.body;
    const { role } = req.body;
    const { otp } = req.body;

    // checking user type

    if (role == "admin") {
      return res
        .status(401)
        .json({ status: false, error: "admin cannot reset the password" });
    }

    // getting current user
    const currentUser = await User.findOne({
      where: {
        email: email,
      },
    });

    // console.log(currentUser.dataValues);
    if (!currentUser) {
      return res.status(400).json({
        message: "error",
        error: "user does not  exists!",
        success: false,
      });
    }

    // get otp session  id from user db

    const otpMatched = await User.verifyOtp(
      otp,
      currentUser.dataValues.otp,
      currentUser.dataValues.expiry
    );
    // console.log(otpMatched);
    if (otpMatched) {
      // updating password in database
      const [affectedRows] = await User.update(
        {
          password: password,
          otp: "",
          // expiryTime: ""
        },
        {
          where: {
            email: email,
          },
        }
      );

      console.log(affectedRows);

      if (affectedRows > 0) {
        return res.status(201).json({
          success: true,
          data  : "password reset successfully",
        });
      } else {
        // No rows were updated (possibly no changes made)
        return res.status(400).json({
          success: false,
          error: "No changes made to the password",
        });
      }
    }

    return res.status(401).json({
      success: false,
      error: "invalid or expired otp",
    });
  } catch (error) {
    console.log(error);
    if (error.name === "SequelizeValidationError") {
        const validationErrors = error.errors.map((err) => ({
          field: err.path,
          message: err.message,
        }));

  
        return res.status(400).json({
          error: "Validation failed",
          details: validationErrors,
          success: false,
        });
      }


    else if (error.name =="SequelizeUniqueConstraintError")
    {

        const constraintErrors = error.errors.map((err) => ({
            field: err.path,
            message: err.message,
          }));
        return res.status(400).json({
            error: constraintErrors,
            details:"constraint error",
            success: false,
          });
    }
    res.status(500).json({
      message: "error",
      error: "something went wrong changing password",
      success: false,
    });
  }
};
