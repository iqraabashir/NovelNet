const Question   = require("../models/question")
module.exports = async (req, res) => 
{

    try {

        const {exam_id }  = req.params
        const { offset , limit } = req.query
        



    const questions  = await Question.findAll({
        where: {
            exam_id,
        
        },
        // limit:parseInt(limit),
        // offset:parseInt(offset)
    })
    if (!questions)
    {
        return res.status(400).json({
            error:"no questins exist. try adding a question first",
            success:false
        })
    }
    


const count = await Question.count({
    where: {
        exam_id
    }
})

    return res.status(200).json({
        message:"ok",
        data:{questions: questions, count},
        success:true,
        

    })




}

catch (error)  {
    console.log(error)
    return res.status(500).json({
        success:false, error:"internal server error"
    })
} 


}