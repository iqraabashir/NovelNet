const Subscriptions = require("../models/subscriptions")
const stripe =  require("stripe")("sk_test_51OeccASJoRkS9gA2MGwe27UOyahpbPFDFGCBMiwuYWTky6XheIbd1hwaPgJl0XaJ489XnYy95kZg7un2KmYTvonb00XO3IOpHF")
// Helper function to check if a date is within the last 30 days
function isPaymentWithinLast30Days(lastPaymentDate) {
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 1);
  
    return lastPaymentDate && new Date(lastPaymentDate) < thirtyDaysAgo;
  }

  
module.exports = async (req, res) => {
    try {



        const subscriptions = await Subscriptions.findOne({
            where: {
                user_id:req.user.token.id
            },
            order:[  ["subscription_id", "DESC"] ]
        })


        if (subscriptions)
        {
            const todayDate= new Date() 
        const endDated = new Date (subscriptions.dataValues.end_date)

        // console.log(startDate)
        // console.log(endDate)
    //     const expiry = todayDate - endDated

    //     console.log(expiry)                                 

    //    const result = expiry / (1000 * 3600 * 24 );

    //    console.log(result)

       if (todayDate < endDated  )
       {
        return res.status(401).json({
            success:false
            ,
            error:"subscription exists"
        })  
       }

           
        }


        


        const { intentId } = req.body;

        // Verify the payment with the Stripe API
        const paymentIntent = await stripe.paymentIntents.retrieve(intentId);
    
        console.log(paymentIntent)
        if (paymentIntent.status != "succeeded" && isPaymentWithinLast30Days(paymentIntent.createdAt)) {
          // Payment is successful, add a subscription or update user's payment status
          // Add your logic here
      return    res.status(400).json({ error: 'Payment verification failed' });
   
        }
        const endDate = new Date();
        endDate.setDate(endDate.getDate() + 360);

        const {id} = req.user.token
    
        // console.log(id)
        
        const subscription = await Subscriptions.create({
            user_id:id,
            start_date:new Date(),
            end_date: endDate 
        })
   

            
        
        return res.status(200).json({
            success:true,
            data: subscription
        })
      

    }


    catch (error) {
        console.log(error)
        return res.status(500).json({
            success:false,
            error:"something went wrongg"
        })
    }
}