const sequelize =  require("../config/db")
const Student = require("../models/student");
const User = require("../models/user");
module.exports = async (req, res) => {
    const t = await sequelize.transaction()
    try {
    const {
      student_id,
      full_name,
      course_id,
      date_of_birth,
      contact_number,
      other_details,
      email,
      user_id,
    } = req.body;
    const user = await User.findByPk(user_id)
    // console.log(user)
    const profile = await Student.findByPk(student_id);

    if (!profile || !user) {
      return res.status(400).json({
        message: "profile or user does not exist",
        success: false,
      });
    }
    console.log("reached update user")
    await user.update({
      email
    },
    {
      transaction:t,
      lock:true
    })
    console.log("reached update profile")
    await profile.update({
      full_name,
      course_id,
      date_of_birth,
      contact_number,
      other_details,
    },
    {
      transaction:t,
      lock:true
    }
    );
    
    console.log("reached end update profile")


    // (await t).commit();
    await t.commit()
    return res.status(201).json({
      message: "profile updated successfully",
      data: profile.dataValues,
      success: true,
    });
  } catch (error) {
    await t.rollback()
    console.log(error);
    if (error.name === "SequelizeValidationError") {
      const validationErrors = error.errors.map((err) => ({
        field: err.path,
        message: err.message,
      }));

      return res.status(400).json({
        error: "Validation failed",
        details: validationErrors,
        success: false,
      });
    } else if (error.name == "SequelizeUniqueConstraintError") {
      const constraintErrors = error.errors.map((err) => ({
        field: err.path,
        message: err.message,
      }));
      return res.status(400).json({
        error: constraintErrors,
        details: "constraint error",
        success: false,
      });
    }
    return res.status(500).json({
      success: false,
      error: "internal server error",
    });
  }
};
