// const Course   = require("../models/course")
const Subject = require("../models/subject");
module.exports = async (req, res) => {
  try {
    const { title, course_id, icon } = req.body;

    const subjectExists = await Subject.findOne({
      where: {
        title,
        course_id,
      },
    });
    if (subjectExists) {
      return res.status(400).json({
        error: "subject already exists ",
        success: false,
      });
    }

    const subject = await Subject.create({
      title,
      course_id,
      icon,
    });

    return res.status(201).json({
      message: "subject added successfully",
      data: subject.dataValues,
      success:true
    });
  } catch (error) {
    console.log(error);
    if (error.name === "SequelizeValidationError") {
      const validationErrors = error.errors.map((err) => ({
        field: err.path,
        message: err.message,
      }));

      return res.status(400).json({
        error: "Validation failed",
        details: validationErrors,
        success: false,
        // error:error
      });
    } else if (error.name == "SequelizeUniqueConstraintError") {
      const constraintErrors = error.errors.map((err) => ({
        field: err.path,
        message: err.message,
      }));
      return res.status(400).json({
        error: constraintErrors,
        details: "constraint error",
        success: false,
      });
    }
    return res.status(500).json({
      success: false,
      error: "internal server error",
    });
  }
};
