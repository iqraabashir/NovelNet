const PrivateSession = require("../models/privateSession");
const Student = require("../models/student");
module.exports = async (req, res) => {
  try {
    const privateSessions = await PrivateSession.findAll({
      order: [["session_id", "DESC"]],
      include: {
        model:Student,
        attributes:["full_name","contact_number"]
        
      },raw:true
    });
    if (!privateSessions) {
      return res.status(400).json({
        error: "no private sessions are available",
        success: false,
      });
    }

    return res.status(200).json({
      success: true,
      data: privateSessions,
    });
  } catch (err) {
    console.log(err)

    return res.status(500).json({
      success: false,
      error: "Internal Server error",
    });
  }
};
