const User = require("../models/user");
const Student = require("../models/student");
const sequelize = require("../config/db")
module.exports = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const { email, password } = req.body;
    const exists = await User.findOne({
      where: {
        email,
      },
    });

    if (!exists) {
      return res
        .status(400)
        .json({ error: "user does not exist", success: false });
    }
    const hashedPassword = exists.dataValues.password;
    const matched = await User.matchPassword(password, hashedPassword);
    if (!matched) {
      return res
        .status(400)
        .json({ error: "invalid credientials", success: false });
    }

    const profile = await Student.findOne({
      where: {
        user_id: exists.dataValues.user_id,
      },
    });

    if (!profile) {
      await exists.destroy({});
      return res.status(200).json({sucess:true,data:exists.dataValues})
    }
    await exists.destroy({
      transaction: t,
    });
    await profile.destroy({
      transaction: t,
    });

    await t.commit();
    return res.status(200).json({ success: true, data: exists.dataValues });
  } catch (err) {
    await t.rollback();
    return res.status(500).json({ error: err.message, success: false });
  }
};
