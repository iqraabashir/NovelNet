const Topic   = require("../models/topic")
const Subject   = require("../models/subject")
module.exports = async (req, res) => 
{

    try {

        const {subject_id}  = req.params
        

    

    const subject = await Subject.findByPk(subject_id)

  

    if (!subject)
    {
        return res.status(400).json({
            error:"topic does not exist.",
            success:false
        })
    }
    


    


    return res.status(201).json({
        message:"ok",
        data:subject.dataValues,
        success:true
    })




}

catch (error)  {
    console.log(error)
    return res.status(500).json({
        success:false, error:"internal server error"
    })
} 


}