const Course = require("../models/course");
const Student = require("../models/student");
const User = require("../models/user");

module.exports = async (req, res) => {
  try {
      console.log(req.user)
    const user_id = req.user.token.id;
    const user = await User.findByPk(user_id)
    console.log('working')
    if (user.dataValues.account_confirmed == false) {
      return res.status(400).json({
        success: false,
        error: "account not verfied",
        data:user.dataValues
      });
    }
    
    user.dataValues.password= ""
    return res.status(200).json({
      data: user.dataValues,
      success: true,
      message: "ok",
    });
  } catch (error) {
    console.log(error)
    return res.status(500).json({
      error: "internal server error",
      success: false,
    });
  }
};
