const User = require("../models/user");
const Student = require("../models/student");
const Course = require("../models/course");
const { Op } = require("sequelize");
module.exports = async (req, res) => {
  try {
    const { user_id } = req.params;
    const user = await User.findOne({
      attributes: ['user_id', 'email'],
      where: {
        user_id,
        user_role: {
          [Op.not]: "admin",
        },
        
      },
      include: [
        {
          model: Student,

          attributes: [
            "student_id",
            "full_name",
            "date_of_birth",
            "contact_number",
            "other_details",
          ],
          include: {
            model: Course,
            attributes: ["course_name"],
          },
        },
        // {
        // }
      ],
      raw: true,
    });
    if (!user) {
      return res.status(400).json({
        error: "user does not exist. try adding the user first",
        success: false,
      });
    }

    return res.status(200).json({
      message: "ok",
      data: user,
      success: true,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      success: false,
      error: "internal server error",
    });
  }
};
