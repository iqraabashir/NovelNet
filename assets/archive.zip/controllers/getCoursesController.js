const Course = require("../models/course");

module.exports = async (req, res) => {
  try {


    const courses  = await Course.findAll()


    if (!courses)
    {
        return res
      .status(400)
      .json({ message: "no course exist", success: false});
    }




        return res.status(201).json({message :"ok", success:true , data:courses})
    
  } catch (error) {
    console.log(error.name)
    if (error.name === "SequelizeValidationError") {
        const validationErrors = error.errors.map((err) => ({
          field: err.path,
          message: err.message,
        }));

  
        return res.status(400).json({
          error: "Validation failed",
          details: validationErrors,
          success: false,
        });
      }


    else if (error.name =="SequelizeUniqueConstraintError")
    {

        const constraintErrors = error.errors.map((err) => ({
            field: err.path,
            message: err.message,
          }));
        return res.status(400).json({
            error: constraintErrors,
            details:"constraint error",
            success: false,
          });
    }
    return res
      .status(400)
      .json({ error: "internal servor error", success: false });
  }
};

