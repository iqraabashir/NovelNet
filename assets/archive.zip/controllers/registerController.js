const User = require("../models/user");
const sendOtp = require("../utills/sendOtp");
const constants  =  require("../constants/index")
module.exports = async (req, res) => {
  try {
    const { role } = req.body;
    // getting the phone and pass from body
    // console.log(req.body)
    if (!role) {
      return res
        .status(400)
        .json({ error: "please enter user role", success: false });
    }
    // if (role == "admin") {
    //   return res
    //     .status(401)
    //     .json({ error: "cannot register as an admin", status: false });
    // }

    const { email, password } = req.body;
    // checking whether user exits
    const exists = await User.findOne({
      where: {
        email: email,
      },
    });
    console.log(exists);

    if (exists) {
      return res.status(409).json({
        error: "user already exists!",
        success: false,
      });
    }

    console.log("workung");
    const response = await User.generateOtp();
    console.log(response);
    if (response.error) {
      return res
        .status(401)
        .json({ error: "sending otp failed", success: false });
    }

    


    // send otp 


  //  const info =  await sendOtp(email ,response.otp,constants.APP_NAME, constants.LOGO_URL)
    console.log(response)
    const newUser = await User.create({
      email: email,
      password: password,
      user_role: role,
      // otp: response.hashedOtp,
      // expiry:response.expiry
    });

    // newUser.save(async function async(err, result) {
    //   if (err)
    //     return res.status(400).json({
    //       error: "something went wrong. Please try again later",
    //       message: "error",
    //       success: false,
    //     });

    // TODO send otp

    //   const token = await newUser.generateToken();

    // **            end of block

    // result.otpSessionId = "";
    //   result.password = "";

    const token = User.generateToken(parseInt(newUser.dataValues.user_id));
    const options = {
      expires: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
      httpOnly: true,
    };

    newUser.dataValues.password = ""
    newUser.dataValues.otp = ""

    if (token) {
      res.status(201).cookie("token",token , options).json({
        message: "registeration  successfull",
        success: true,
        data: {...newUser.dataValues, token:token},
        // token: token,
      });
    }

    
  } catch (error) {
    // console.log(err);
    if (error.name === "SequelizeValidationError") {
      const validationErrors = error.errors.map((err) => ({
        field: err.path,
        message: err.message,
      }));


      return res.status(400).json({
        error: "Validation failed",
        details: validationErrors,
        success: false,
      });
    }


  else if (error.name =="SequelizeUniqueConstraintError")
  {

      const constraintErrors = error.errors.map((err) => ({
          field: err.path,
          message: err.message,
        }));
      return res.status(400).json({
          error: constraintErrors,
          details:"constraint error",
          success: false,
        });
  }

    console.log(error)
    res.status(500).json({
      //   message: "error",
      error: "something went wrong!. Please try again later",
      success: false,
    });
  }
};
