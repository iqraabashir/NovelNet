const Meeting= require("../models/meeting") 
module.exports = async (req,res) => {

    try {

        const {course_id} = req.params
        console.log(course_id)

        const meetings = await Meeting.findAll({
            where: {
                course_id
            },
            order: [
                ["meeting_id", "DESC"]

            ]
        })
        
        return res.status(200).json({
            success:true,
            data:meetings
        })
        

    }

    catch (error)
    {
        console.log(error)
        return res.status(500).json({
            success:false,
            error:"Internal servor error"
        })
    }


}