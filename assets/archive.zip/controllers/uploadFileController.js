// const multer = require("multer");
// const multerS3 = require('multer-s3');
const AWS = require("aws-sdk");
require("dotenv").config();
AWS.config.update({
  accessKeyId: process.env.WASABI_ACCESS_ID,
  secretAccessKey: process.env.WASABI_SECRET_ID,
  region: "singapore-ap-southeast", // Update with your desired region,
});

const s3 = new AWS.S3({
  endpoint: new AWS.Endpoint("s3.ap-southeast-1.wasabisys.com"),
});
// const upload = multer()

module.exports = async (req, res) => {
  console.log("working");
  const file = req.file;
  console.log(file);
  const params = {
    Bucket: "crescentclassesvideos",
    Key: file.originalname,
    Body: file.buffer,
    ContentType: file.mimetype,
  };

  try {
    const response = await s3.upload(params).promise();
    res.status(200).json({ data: response, success: true });
  } catch (error) {
    console.error(error);
    res.status(500).json({ msg: "true" });
  }
};
