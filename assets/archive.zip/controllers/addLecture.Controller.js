const Topic = require("../models/topic");
// const Course   = require("../models/course")
const Lecture = require("../models/lecture");
const Assignment = require("../models/assignments");

module.exports = async (req, res) => {
  try {
    const {
      topic_id,
      title,
      video_key,
      meeting_link,
      course_id,
      // assignment_urls,
      is_paid,
      subject_id,
    } = req.body;

    const topic = await Topic.findByPk(topic_id);
    if (!topic) {
      return res.status(400).json({
        error: "please select a topic",
        success: false,
      });
    }

    const exists = await Lecture.findOne({
      where: {
        title,
        topic_id,
        course_id,
        subject_id,
      },
    });

    if (exists) {
      return res
        .status(401)
        .json({ success: false, error: "lecture already exists",message:"err" });
    }

    const lecture = await Lecture.create({
      topic_id,
      title,
      video_key,
      meeting_link,
      course_id,
      subject_id,
      is_paid
    });

    return res.status(201).json({
      message: "lecture added successfully",
      data: { ...lecture.dataValues },
      success: true,
    });
  } catch (error) {
    console.log(error);
    if (error.name === "SequelizeValid ationError") {
      const validationErrors = error.errors.map((err) => ({
        field: err.path,
        message: err.message,
      }));

      return res.status(401).json({
        error: "Validation failed",
        details: validationErrors,
        success: false,
      });
    } else if (error.name == "SequelizeUniqueConstraintError") {
      const constraintErrors = error.errors.map((err) => ({
        field: err.path,
        message: err.message,
      }));
      return res.status(401).json({
        error: constraintErrors,
        details: "constraint error",
        success: false,
      });
    }
    return res.status(500).json({
      success: false,
      error: "internal server error",
    });
  }
};
