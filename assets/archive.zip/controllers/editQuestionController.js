const Topic   = require("../models/topic")
const Question   = require("../models/question")
module.exports = async (req, res) => 
{

    try {

        const {
            question_id,
            question,
            option_1,
            option_2,
            option_3,
            option_4,
            answer,
            explanation,
            // exam_id
          } = req.body;
              


    

    const questionExists = await Question.findByPk(question_id)
  

    if (!questionExists)
    {
        return res.status(400).json({
            message:"question does not exist",
            success:false
        })
    }
    


    const updatedQuestion = await questionExists.update({
        question,
        option_1,
        option_2,
        option_3,
        option_4,
        answer,
        explanation
    })

    

    return res.status(201).json({
        message:"question updated successfully",
        data:updatedQuestion.dataValues
    })




}

catch (error)  {
    console.log(error)
    if (error.name === "SequelizeValidationError") {
        const validationErrors = error.errors.map((err) => ({
          field: err.path,
          message: err.message,
        }));

  
        return res.status(400).json({
          error: "Validation failed",
          details: validationErrors,
          success: false,
        });
      }


    else if (error.name =="SequelizeUniqueConstraintError")
    {

        const constraintErrors = error.errors.map((err) => ({
            field: err.path,
            message: err.message,
          }));
        return res.status(400).json({
            error: constraintErrors,
            details:"constraint error",
            success: false,
          });
    }
    return res.status(500).json({
        success:false, error:"internal server error"
    })
} 


}