const Notification = require("../models/notification.js");
const sendPushNotifications = require("../utills/sendPushNotifications");
const User = require("../models/user");
// const { Student } = require("../associations.js");
const Student = require("../models/student.js");
const PushTokens = require("../models/pushTokens.js");
module.exports = async (req, res) => {
  try {
    const { title, body, course_id } =
      req.body;

    const notification = await Notification.create({
        title,
        body,
        course_id
    });

    const somePushTokens = await User.findAll({
      //  attributes: ["push_token"],
      include: [
        {
          model: Student,
           attributes:["course_id"],
          where: {
            course_id,
          },
        },
        {
           
            model:PushTokens,
            attributes:["push_token"],
        }
      
      ],
      raw: true,
    });

    // console.log(somePushTokens);

    // console.log(somePushTokens[0].push_token);
    // TODO send push notifications to students
    const expoPushTokens = somePushTokens.map((set) => {
      return set['Push_Tokens.push_token'];
    });

    // console.log(expoPushTokens)
    sendPushNotifications(expoPushTokens, title, body);
    // console.log(expoPushTokens)
    return res.status(200).json({
      success: true,
      data: notification,
      // message:"ok"
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      error: "something went wrong",
      success: false,
    });
  }
};
