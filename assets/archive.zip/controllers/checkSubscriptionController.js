const Subscriptions = require("../models/subscriptions")

module.exports = async (req,res) => {
    try {

        const {id} =  req.user.token
        const subscription  = await Subscriptions.findOne({
            where: {
                user_id:id

            },
            order:[["subscription_id", "DESC"]]
        })
        
        if (!subscription)
        {
            return res.status(401).json({
                success:false
                ,
                data:"no subscription"
            })  
        }

        const todayDate= new Date()
        const endDate = new Date (subscription.dataValues.end_date)

       if (todayDate >  endDate)
       {
        return res.status(401).json({
            success:false
            ,
            data:"no subscription"
        })  
       }

        return res.status(200).json({
            success:true,
            data:subscription.dataValues.end_date
        })  
    }

    catch (err)

    {
        console.log(err)
        return res.status(500).json({
            success:false,
            error:"internal server error"
        })
    }
}