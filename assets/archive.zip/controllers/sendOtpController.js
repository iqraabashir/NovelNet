const sendOtp = require("../utills/sendOtp");
const User = require("../models/user");
const constants = require("../constants/index");
module.exports = async (req, res) => {
  try {
    const { email } = req.body;
    const user = await User.findOne({
      where: {
        email,
      },
    });

    if (!user) {
      return res
        .status(400)
        .json({ error: "user does not exist", success: false });
    }

    const response = await User.generateOtp();
    console.log(response);
    if (response?.error) {
      return res
        .status(400)
        .json({ success: false, error: "something went wrong sending otp" });
    }

    const otpResp = await sendOtp(
      email,
      response.otp,
      constants.APP_NAME,
      constants.LOGO_URL
    );
    // console.log("otpres",otpResp);
    if (otpResp?.err) {
      return res
        .status(400)
        .json({ success: false, error: "something went wrong sending otp" });
    }

    const [affectedRows] = await User.update(
      { otp: response.hashedOtp, expiry: response.expiry },
      {
        where: {
          email: email,
        },
      }
    );

    console.log(affectedRows);
    if (affectedRows > 0) {
      return res.status(201).json({ success: true, message: "otp sent" });
    }
  } catch (err) {
    console.log(err);
    return res
      .status(500)
      .json({ success: false, error: "internal servor error" });
  }
};
