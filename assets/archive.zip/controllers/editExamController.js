const Exam  = require("../models/mockExam")
module.exports = async (req, res) => 
{

    try {

        const {exam_id, title, description}  = req.body
        


    

    const exam = await Exam.findByPk(exam_id)
  

    if (!exam)
    {
        return res.status(400).json({
            message:"exam does not exist",
            success:false
        })
    }
    


    await exam.update({
        title,
        description
    })

    

    return res.status(201).json({
        message:"exam  updated successfully",
        data:exam.dataValues,
        success:true
    })




}

catch (error)  {
    console.log(error)
    if (error.name === "SequelizeValidationError") {
        const validationErrors = error.errors.map((err) => ({
          field: err.path,
          message: err.message,
        }));

  
        return res.status(400).json({
          error: "Validation failed",
          details: validationErrors,
          success: false,
        });
      }


    else if (error.name =="SequelizeUniqueConstraintError")
    {

        const constraintErrors = error.errors.map((err) => ({
            field: err.path,
            message: err.message,
          }));
        return res.status(400).json({
            error: constraintErrors,
            details:"constraint error",
            success: false,
          });
    }
    return res.status(500).json({
        success:false, error:"internal server error"
    })
} 


}