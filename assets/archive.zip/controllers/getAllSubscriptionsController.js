const Subscriptions = require("../models/subscriptions");
const User = require("../models/user");
const Student = require("../models/student");
const {Op} = require("sequelize")
module.exports = async (req, res) => {
  try {
    const subscriptions = await User.findAll({
        where: {
            user_role: {
              [Op.not] :"admin"
            
            },
          },
      include: [
        {
          model: Subscriptions,
        
          attributes: ["subscription_id", "start_date", "end_date", "user_id"],
        where: {
            subscription_id:{

                [Op.not] : "null"
            }

        }
        },
      ],
      raw:true
    });

    if (!subscriptions) {
      return res.status(400).json({
        error: "no subscriptions",
        success: true,
      });
    }

    return res.status(200).json({
      success: true,
      data: subscriptions,
    });
  } catch (err) {
    return res.status(500).json({
      success: false,
      error: "internal server error",
    });
  }
};
