const Exam   = require("../models/mockExam")
module.exports = async (req, res) => 
{

    try {

        const {course_id}  = req.params
        

    

    const exams  = await Exam.findAll({
        where: {
            course_id
        },
        order:[["exam_id","DESC"]]
    })
    if (!exams)
    {
        return res.status(400).json({
            error:"no exams exist. try creating an exam first",
            success:false
        })
    }
    




    return res.status(200).json({
        message:"ok",
        data:exams,
        success:true
    })




}

catch (error)  {
    console.log(error)
    return res.status(500).json({
        success:false, error:"internal server error"
    })
} 


}