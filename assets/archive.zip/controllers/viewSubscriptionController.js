const Subscriptions = require("../models/subscriptions");
const User = require("../models/user");

module.exports = async (req, res) => {
  const { subscription_id } = req.params;

  try {
    const subscription = await Subscriptions.findByPk(subscription_id, {
      include: {
        model: User,
      },
      raw:true
    });
    if (!subscription) {
      return res.status(400).json({ error: "subscription does not exist" });
    }

    // subscription..user['user.password'] = "";
    console.log(subscription["user.password"]= null)
    console.log(subscription["user.otp"]= null)
    // subscription.dataValues.user.otp = "";
    return res.status(200).json({ success: true, data: subscription });
  } catch (err) {
    console.log(err)
    return res.status(400).json({
      sucess: false,
      error: "internal server error",
    });
  }
};
