const Assignment = require("../models/assignments");
const { Op } = require("sequelize");
const User = require("../models/user");
const Lecture = require("../models/lecture");
const Subscriptions = require("../models/subscriptions");
const getPresignedUrl = require("../utills/getPresignedUrl");
module.exports = async (req, res) => {
  try {
    const { lecture_id } = req.params;

    const lecture = await Lecture.findByPk(lecture_id);

    const assignments = await Assignment.findAll({
      where: {
        lecture_id,
      },
    });

    if (!lecture) {
      return res.status(400).json({
        error: "lecture does not exist.",
        success: false,
      });
    }

    const user = await User.findByPk(req.user.token.id);
    if (user.dataValues.user_role != "admin") {
      // check if subsription exists
      const nowDate = Date.now();
      if (lecture.is_paid) {
        const subscription = await Subscriptions.findOne({
          where: {
            user_id: req.user.token.id,
          },
          order: [["subscription_id", "DESC"]],
        });

        if (!subscription) {
          return res.status(401).json({
            success: false,
            error: "Subscriptions is needed for premium videos",
          });
        }

        const todayDate = new Date();
        const endDate = new Date(subscription.dataValues.end_date);

        if (todayDate > endDate) {
          return res.status(401).json({
            success: false,
            error: "Subscriptions is needed for premium videos",
          });
        }
      }
    }

    const { url: video_url } = getPresignedUrl(
      lecture.dataValues.video_key,
      60 * 60
    );

    return res.status(201).json({
      message: "ok",
      data: { ...lecture.dataValues, assignments, video_url },
      // assignments:{...assignment,lecture},
      success: true,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      success: false,
      error: "internal server error",
    });
  }
};
