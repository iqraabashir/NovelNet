const User = require("../models/user");
const sendOtp = require("../utills/sendOtp");
const constants = require("../constants/index");
const PushTokens = require("../models/pushTokens")
module.exports = async (req, res) => {
  try {
    // const { role } = req.body;
    // getting the phone and pass from body
    // console.log(req.body)
    // if (!role) {
    //   return res
    //     .status(400)
    //     .json({ error: "please enter user role", success: false });
    // }

    console.log(req.body)
    const { email, password,push_token} = req.body;
    // checking whether user exits
    const user = await User.findOne({
      where: {
        email: email,
      },
    });

    if (!user) {
      return res
        .status(401)
        .json({ error: "no such user exists", success: false });
    }

    const isMatch = await User.matchPassword(
      password,
      user.dataValues.password,
    );

    

    // console.log(exists);

    if (!isMatch) {
      return res.status(401).json({
        error: "invalid credentials",
        success: false,
      });
    }

    // console.log("workung");
    // const response = await User.generateOtp();
    // console.log(response);
    // if (response.error) {
    //   return res
    //     .status(401)
    //     .json({ error: "sending otp failed", success: false });
    // }

    // send otp

    // sendOtp(email ,response.otp,constants.APP_NAME, constants.LOGO_URL)

    // const newUser = await User.create({
    //   phone: phone,
    //   password: password,
    //   user_role: role,
    //   otp: response.hashedOtp,
    //   expiryTime:response.expiry
    // });

    // newUser.save(async function async(err, result) {
    //   if (err)
    //     return res.status(400).json({
    //       error: "something went wrong. Please try again later",
    //       message: "error",
    //       success: false,
    //     });

    // TODO send otp

    //   const token = await newUser.generateToken();

    // **            end of block

    // result.otpSessionId = "";
    //   result.password = "";
    user.dataValues.password = "";
    user.dataValues.otp = "";

    const token = User.generateToken(parseInt(user.dataValues.user_id));
    const options = {
      expires: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
      httpOnly: true,
    };

    // req.session.token= token

    // const updatedUser = await user.update({
    //   push_token
    // })


      // return res.status(200)
      // console.log(push_token)



      console.log("reached here .....................")
      console.log(push_token)
      console.log("reached here .....................")
      if (push_token)   
      {
        console.log("reached here .....................")
        console.log("reached here .....................")
        console.log("reached here .....................")
        console.log("reached here .....................")
        console.log("reached here .....................")
        console.log("reached here .....................")
        console.log("reached here .....................")
        console.log("reached here .....................")
        console.log("reached here .....................")
        console.log("reached here .....................")
        console.log("reached here .....................")
        console.log("reached here .....................")
        console.log("reached here .....................")
        console.log("reached here .....................")
        console.log("reached here .....................")
        console.log("reached here .....................")
        console.log("reached here .....................")
        const pushTokenExists = await PushTokens.findOne({
          where: {
            push_token
          }
        })
        
        
      console.log(pushTokenExists)
      if (!pushTokenExists)
    { 
      

      await PushTokens.create({
        push_token,
        user_id:user.dataValues.user_id
        
      })
    }
  }
      res.status(201).cookie("token",token , options).json({
        message: "login successfull",
        success: true,
        data: {...user.dataValues, token:token},
        // token: token,
      });
  
  } catch (error) {
    // console.log(err);
    if (error.name === "SequelizeValidationError") {
      const validationErrors = error.errors.map((err) => ({
        field: err.path,
        message: err.message,
      }));


      return res.status(400).json({
        error: "Validation failed",
        details: validationErrors,
        success: false,
      });
    }


  else if (error.name =="SequelizeUniqueConstraintError")
  {

      const constraintErrors = error.errors.map((err) => ({
          field: err.path,
          message: err.message,
        }));
      return res.status(400).json({
          error: constraintErrors,
          details:"constraint error",
          success: false,
        });
  }
    console.log(error);
    res.status(500).json({
      //   message: "error",
      error: "something went wrong!. Please try again later",
      success: false,
    });
  }
};
