const pageNotFound  = (req,res)=>{ 
    res.status(404).json({error:"route not found" ,success:false})
}
module.exports = pageNotFound
