const { Sequelize } = require("sequelize");
require("dotenv").config();
const sequelize = new Sequelize({
  //   host: "precepttechnologies.co.in",
  // host: "hoteljamawar.com",
  host: "localhost",
  dialect: "mysql",
  username: process.env.DB_USER,
  // username: "u149622416_tutorapp",
  // port:3306,
  // username:"u149622416_tutorapp",
  database: "crescentclasses",
  // database: "u149622416_tutorapp",
  // database:"tutorapp",
  password: process.env.DB_PASS,
  // password: "@Onfire*123#",
});

sequelize
  .authenticate()
  .then(() => {
    console.log("Connection has been established successfully.");
  })
  .catch((error) => {
    console.error("Unable to connect to the database: ", error);
  });

module.exports = sequelize;
